Used Softwares
==============

+ Stanford POS Tagger - v3.4.0
+ MaltParser - v1.8
